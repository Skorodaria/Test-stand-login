import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Avtotest1 {
    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();

        WebDriver webDriver = new ChromeDriver();
        webDriver.get("https://test-stand.gb.ru/login");

        By driver;
        Actions element;

        element.sendKeys("GB202301271f47");
        WebElement element1 = driver.findElement(By.xpath("//*[@id=\"login\"]/div[1]/label/input"));
        element1.clear();
        element1.sendKeys("d885669b8b");
        WebElement element2 = driver.findElement(By.xpath("(//*[@id=\"login\"]/div[2]/label"));
        WebElement element3 = driver.findElement(By.xpath("//*[@id=\"login\"]/div[3]/button/div")).click();
        driver.findElement(By.xpath("//*[@id=\"login\"]/div[1]/label/input")).clear();
        driver.findElement(By.xpath("//*[@id=\"login\"]/div[1]/label/input")).sendKeys("      ");
        driver.findElement(By.xpath("//*[@id=\"login\"]/div[2]/label/input")).clear();
        driver.findElement(By.xpath("(//input[@name='password'])[1]")).sendKeys("      ");
        driver.findElement(By.xpath("//*[@id=\"login\"]/div[3]/button/div")).click();
        driver.findElement(By.xpath("//*[@id=\"app\"]/main/nav/ul/li[3]/div/ul/li[3]/span[2]")).click();

        WebElement mat = driver.findElement(By.xpath("(//input[@name='password_check'])[1]"));
        mat.sendKeys("qwerty1234");


        //element4.submit();
        //element4.click();

    }

}