import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
class Avtotest1Test {

    WebDriver driver;
    WebDriverWait webDriverWait;
    Actions actions;


    @BeforeAll
    static void registerDriver() {
        WebDriverManager.chromedriver().setup();
    }

    @BeforeEach
    void initDriver() {
        driver = new ChromeDriver();
        webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(5));
        driver.get("https://test-stand.gb.ru/login");
    }

    @Test
    void LoginTest() throws InterruptedException {
        List<WebElement> Testlogin = driver.findElements(By.xpath("//*[@id=\"login\"]/div[3]/button/div"));
        Testlogin.get(0).click();
        driver.findElement(By.xpath("//*[@id=\"login\"]/div[3]/button/div")).click();
        Thread.sleep(6000);


        driver.switchTo().frame(driver.findElement(By.xpath(//cms-mini-account[//*[@id="app"]/main/nav/ul/li[3]/div/ul/li[3]/span[2]]));

                Assertions.assertTrue(driver.findElement(By.xpath("//*[@id=\"app\"]/main/nav/ul/li[3]/div/ul/li[3]/span[2]")).isDisplayed());

    }



    @AfterEach
    void tearDown() {
        driver.manage().deleteAllCookies();
        driver.quit();
    }

}